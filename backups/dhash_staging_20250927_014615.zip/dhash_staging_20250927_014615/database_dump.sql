-- dhash Database Backup
-- Environment: staging
-- Created: Sat Sep 27 01:46:15 UTC 2025
-- Database: dhash_staging

-- Sample data structure
CREATE TABLE dhash_entries (
    id SERIAL PRIMARY KEY,
    hash_key VARCHAR(64) NOT NULL UNIQUE,
    hash_value VARCHAR(128) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Sample data
INSERT INTO dhash_entries (hash_key, hash_value) VALUES 
    ('test_key_1', 'sha256:abc123def456'),
    ('test_key_2', 'sha256:def789ghi012'),
    ('test_key_3', 'sha256:ghi345jkl678');

-- Performance metrics table
CREATE TABLE dhash_performance_metrics (
    id SERIAL PRIMARY KEY,
    metric_name VARCHAR(64) NOT NULL,
    metric_value DECIMAL(10,2) NOT NULL,
    recorded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

